import { useState } from 'react'

function App() {
  // Это наши «тестовые» агенты. Потом они будут прилетать с бэкенда.
  const [agents] = useState([
    { id: 1, name: 'Кибер-Иван', mood: 'Радость', color: 'bg-yellow-400' },
    { id: 2, name: 'Нейро-Маша', mood: 'Злость', color: 'bg-red-500' },
    { id: 3, name: 'Бот-Петр', mood: 'Спокойствие', color: 'bg-blue-400' },
  ]);

  return (
    // Главный контейнер на весь экран с темным фоном
    <div className="min-h-screen bg-slate-900 text-white p-8">
      <header className="mb-10">
        <h1 className="text-4xl font-bold text-cyan-400">КИБЕР РЫВОК 2026</h1>
        <p className="text-slate-400">Симулятор жизни AI-агентов</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* ЛЕВАЯ КОЛОНКА: Список агентов (Дашборд) */}
        <div className="lg:col-span-2">
          <h2 className="text-2xl mb-4 font-semibold">Дашборд «Жизнь агентов»</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {agents.map(agent => (
              <div key={agent.id} className="bg-slate-800 p-6 rounded-2xl border border-slate-700 hover:border-cyan-500 transition-all cursor-pointer">
                <div className="flex items-center gap-4">
                  {/* Аватар (цветной круг) */}
                  <div className={`w-12 h-12 rounded-full ${agent.color} flex items-center justify-center text-xl font-bold text-slate-900`}>
                    {agent.name[0]}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">{agent.name}</h3>
                    <p className="text-sm text-slate-400">Настроение: <span className="text-white">{agent.mood}</span></p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ПРАВАЯ КОЛОНКА: Лента событий */}
        <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
          <h2 className="text-2xl mb-4 font-semibold">Лента событий</h2>
          <div className="space-y-4 h-[500px] overflow-y-auto pr-2">
            <div className="text-sm border-l-2 border-cyan-500 pl-3 py-1">
              <span className="text-cyan-400 font-mono">10:00</span> — Кибер-Иван начал спорить с Нейро-Машей.
            </div>
            <div className="text-sm border-l-2 border-slate-600 pl-3 py-1">
              <span className="text-slate-500 font-mono">10:05</span> — Бот-Петр уснул.
            </div>
          </div>
        </div>

      </div>
    </div>
  )
}

export default App